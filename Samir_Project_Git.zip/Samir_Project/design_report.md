﻿This program is an employee system I made for the project. The idea is to keep things simple so a new user can add people and change salaries with no complicated setup.

I split tasks into many small functions. The main part shows the menu and asks for numbers, and the other functions do the work like add, update, delete, give bonus, and calculate statistics. Data is stored in a text file called employees.txt where each line is name,salary. When I update or delete I read the file to a list and then write it back. This way the logic is easy to test.

I used the file handling style using with open so the file closes automatically. I also used a small found flag in some functions to tell if the employee exists so the program can print a message. I know the program can improve: add input checks so letters do not crash the program, handle duplicate names better (maybe use an id), and use a real database if the file becomes large.

I learned how important breaking the work into small functions is and how testing helps catch bugs early. Writing tests and the manual plan helped me find problems and fix them step by step.
