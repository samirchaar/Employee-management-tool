﻿Instructions for Employee System

Hi, this is my project for the employee management system. It is a simple program that helps you manage employees and their salaries in a text file. You can add people, give them money, delete them and see some stats.

To run it you just need python. Open the terminal in the folder and type `python employee_system.py`.

When it starts you will see a menu with numbers.
If you press 1 you can see all employees.
If you press 2 you can add a new one, just type name and salary.
If you press 3 you can change the salary of someone.
If you press 4 you can give a bonus to someone.
If you press 5 you see the payroll report with total money.
If you press 6 you can delete an employee.
If you press 7 you can search for a name.
If you press 8 you see statistics like average salary and highest paid person.
If you press 9 it exits.

The file is saved in employees.txt so if you close it and open it again the data is still there. Please only use numbers for salary.
