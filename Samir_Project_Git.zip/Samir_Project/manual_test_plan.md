﻿This is a simple manual plan to try the program as a user. Start the program with python employee_system.py and then try the steps below.

First check the menu shows the welcome text and numbers for options. Try option 1 when the file is empty to see how it looks. Use option 2 to add a person (name and salary) and then option 1 again to see the new person. Add a second person and try option 3 to change salary, option 4 to give a bonus, option 5 to see the payroll report and total, option 6 to delete someone, option 7 to search for a name, option 8 to see statistics like count and average, and finally option 9 to exit.

Try also bad input like typing a letter when it asks for a number and see how the program responds. Close and open the program to check the data is still in employees.txt.
