﻿I wrote many tests to cover the parts of my program. I used pytest and the tests are in test_employee.py.

The tests check adding employees with normal, zero, and large salaries, and also duplicate names. For updating I tested normal update, updating to zero, and trying to update a name not in the file. For bonuses I tested normal bonus, zero bonus, and negative bonus. For deleting I tested deleting existing and non existing names. I also tested searching and all math functions like count, average, highest and lowest paid and total payroll. I tested those functions with several employees and with an empty file so the code does not crash.

For manual testing I tried the program UI and followed the steps in the manual test plan to check each menu option and file persistence.

I think the automated tests cover almost everything the code does and the manual plan covers the user interface parts.
